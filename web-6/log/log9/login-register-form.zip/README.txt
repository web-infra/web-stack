A Pen created at CodePen.io. You can find this one at http://codepen.io/ianpirro/pen/DzKIJ.

 Kill two birds with one stone... The form will switch from login to register, and back,  based on if the user is already "registered"

Find "registered" users in the js panel.